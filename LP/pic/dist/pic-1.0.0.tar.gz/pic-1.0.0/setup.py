from distutils.core import setup
setup(
	name='pic',
	version ='1.0.0',
	py_modules=['pic'],
	author='tulpar',
	author_email=['tulpar008@gmail.com'],
	url='',
	description='An egg from python',
	)

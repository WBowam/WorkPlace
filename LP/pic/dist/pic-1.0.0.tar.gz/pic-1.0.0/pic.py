#!/usr/bin/python3
import pic_cut
